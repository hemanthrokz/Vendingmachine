package com.VendingMachine.VendingMachine01.controller;

import com.VendingMachine.VendingMachine01.dto.InventoryDTO;
import com.VendingMachine.VendingMachine01.model.InitialBalanceAndPurchaseHistory;
import com.VendingMachine.VendingMachine01.service.AdminServices;
import com.VendingMachine.VendingMachine01.model.Inventry;
import com.VendingMachine.VendingMachine01.service.InventoryService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

@RestController
@Tag(name = "ADMIN PROCESS")
public class AdminController {

    private AdminServices adminServices;
    private InventoryService inventoryService;

    public AdminController( AdminServices adminServices,InventoryService inventoryService) {
        this.adminServices = adminServices;
        this.inventoryService=inventoryService;
    }


////////////////////////////////////////////////////////

    @GetMapping("/delete/{id}")
    @Operation(summary = "ADMIN PROCESS--DELETE  Inventory item ")
    public ModelAndView deleteProductById(@PathVariable int id) {
        adminServices.deleteProductById(id);
        List<InventoryDTO> list= inventoryService.getListOfAllInventory();

        ModelAndView model=new ModelAndView();
        model.addObject("list",list);

        model.setViewName("getEmployee");
        return model;
    }

//
//    @GetMapping("/purchasehistory")
//    @Operation(summary = "CUSTOMER PROCESS--Get LIST OF ALL Inventry item")
//    public List<InitialBalanceAndPurchaseHistory> getListOfAllPurchaseHistory() {
//        return adminServices.getListOfAllPurchaseHistory();
//    }


//    @PostMapping("/products")
//    @Operation(summary = "ADMIN PROCESS--Add  Inventory item ")
//    public String saveInventory(@RequestBody InventoryDTO e) {
//        return adminServices.saveInventory(e) + " product added successfully";
//    }

//    @PutMapping("/productsput/{id}")
//    @Operation(summary = "ADMIN PROCESS--Update  Inventory item ")
//    public String updateInventory(@RequestBody Inventry e, @PathVariable int id) {
//        return adminServices.updateInventory(e, id)+" Product (s) updated successfully";
//    }
//@PutMapping("/productsput/{id}")
//@Operation(summary = "ADMIN PROCESS--Update  Inventory item ")
//public String updateInventory(@RequestBody Inventry e) {
//    return adminServices.updateInventory(e, id)+" Product (s) updated successfully";
//}
////////////////////////////////////
@GetMapping("/addinventoryitem")
public ModelAndView addInventoryItemPage() {
    ModelAndView model=new ModelAndView();
    model.setViewName("addEmployee");
    return model;
}

@RequestMapping(value="add-Inventryitem",method = RequestMethod.POST)
public ModelAndView saveEmployee(HttpServletRequest request) {
    InventoryDTO employee=new InventoryDTO(Integer.parseInt(request.getParameter("productId")), request.getParameter("name"), Integer.parseInt(request.getParameter("productPrice")), Integer.parseInt(request.getParameter("productInventryCount")));
    adminServices.saveInventory(employee) ;
    List<InventoryDTO> list= inventoryService.getListOfAllInventory();

    ModelAndView model=new ModelAndView();
    model.addObject("list",list);

    model.setViewName("getEmployee");
    return model;
}


    //////////////////////////////////////////
    @GetMapping("/update")
    public ModelAndView updateForm() {
        ModelAndView model=new ModelAndView();
        model.setViewName("updateEmployee");
        return model;
    }

    @RequestMapping(value="updateInventory",method=RequestMethod.POST)
    public ModelAndView updateEmployee(HttpServletRequest request) {
        InventoryDTO employee=new InventoryDTO(InventoryDTO.builder());
        employee.builder().productId(Integer.parseInt(request.getParameter("productId")));
        employee.builder().name(request.getParameter("name"));
        employee.builder().productInventryCount(Integer.parseInt(request.getParameter("productInventryCount")));
        employee.builder().productPrice(Integer.parseInt(request.getParameter("productPrice")));
        adminServices.updateInventory(employee) ;
        List<InventoryDTO> list= inventoryService.getListOfAllInventory();
        ModelAndView model=new ModelAndView();
        model.addObject("list",list);
        model.setViewName("getEmployee");
        return model;
    }





}
