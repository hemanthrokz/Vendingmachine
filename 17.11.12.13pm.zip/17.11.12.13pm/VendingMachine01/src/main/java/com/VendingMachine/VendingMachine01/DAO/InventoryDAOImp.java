package com.VendingMachine.VendingMachine01.DAO;

import com.VendingMachine.VendingMachine01.Mapper.InventoryRowMapper;
import com.VendingMachine.VendingMachine01.model.InventoryBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;
import com.VendingMachine.VendingMachine01.model.Inventry;

import java.util.List;

@Repository
public class InventoryDAOImp implements InventoryDAO {

    @Autowired
   JdbcTemplate jdbcTemplate;
    @Autowired
    private NamedParameterJdbcTemplate namedParameterJdbcTemplate;

   public NamedParameterJdbcTemplate getNamedParameterJdbcTemplate() {
        return namedParameterJdbcTemplate;
    }


    @Override
    public List<InventoryBuilder> findAll() {
        String SQL ="SELECT * FROM productlist";
        return getNamedParameterJdbcTemplate().query(SQL, new BeanPropertyRowMapper<InventoryBuilder>(InventoryBuilder.class));
    }

    @Override
    public List<InventoryBuilder> findById(int productId) {
        SqlParameterSource mapSqlParameterSource = new MapSqlParameterSource("productid", productId);
        return getNamedParameterJdbcTemplate().query("SELECT * FROM productlist WHERE productid = :productid ", mapSqlParameterSource , new BeanPropertyRowMapper<InventoryBuilder>(InventoryBuilder.class));
    }

    @Override
    public int updatedStock(int productId, int productInventryCount) {
        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("productid", productId).addValue("productinventrycount", productInventryCount);
        return getNamedParameterJdbcTemplate().update("update productlist set productinventrycount = :productinventrycount where productid = :productid", sqlParameterSource);
    }

//    @Override
//    public Inventry getChange() {
//
//        List<Inventry> changeList = namedParameterJdbcTemplate.query("select initialbalance from Initial_balance where id = 1;", new BeanPropertyRowMapper<Inventry>(Inventry.class));
//        return changeList.get(0);
//
//    }
//
//    @Override
//    public double updateChange(double newChange) {
//
//        SqlParameterSource sqlParameterSource = new MapSqlParameterSource("newChange", newChange);
//        return namedParameterJdbcTemplate.update("update Initial_balance set initialbalance = :newChange where id=1;", sqlParameterSource);
//    }
///////////////////////////////////////////////////////////////////////////

    @Override
    public int  save(Inventry e) {
        String sql ="INSERT INTO productlist (name, productinventrycount, productprice) VALUES (:name, :productinventrycount,:productprice)";
        MapSqlParameterSource paramSource = new MapSqlParameterSource();
        paramSource.addValue("name", e.getName());
        paramSource.addValue("productinventrycount",e.getProductInventryCount());
        paramSource.addValue("productprice", e.getProductPrice());

        int update = getNamedParameterJdbcTemplate().update(sql, paramSource);
        if(update == 1) {
            System.out.println("product is added..");
        }

         return  namedParameterJdbcTemplate.update(sql, paramSource);
    }



    @Override
    public int deleteById(int productId) {
        return jdbcTemplate.update("DELETE FROM productlist WHERE productid=?", productId);
    }

//    @Override
//    public int save(Inventry e) {
//        return jdbcTemplate.update("INSERT INTO customer (name, productinventrycount, productprice) VALUES (?, ?, ?)", new Object[] {e.getName(), e.getProductInventryCount(), e.getProductPrice()});
//    }

    @Override
    public int update(Inventry e, int productId) {
        return jdbcTemplate.update("UPDATE productlist SET name = ?, productinventrycount = ?, productprice = ? WHERE productid = ?", new Object[] {e.getName(), e.getProductInventryCount(), e.getProductPrice(), productId});
    }


    ////////////////////////////////
    @Override
    public List<Inventry> findByProductInventryCount(int productInventryCount){
        return jdbcTemplate.query("select * from productlist where productinventrycount= ?",new BeanPropertyRowMapper<Inventry>(Inventry.class),productInventryCount);
    }

    ////////////////////////////////
}
