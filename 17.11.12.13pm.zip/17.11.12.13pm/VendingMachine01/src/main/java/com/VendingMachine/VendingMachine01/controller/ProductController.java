package com.VendingMachine.VendingMachine01.controller;

import com.VendingMachine.VendingMachine01.DTO.CustomerInputDTO;
import com.VendingMachine.VendingMachine01.DTO.InventoryDTO;
import com.VendingMachine.VendingMachine01.DTO.VendingMachineOutputDTO;
import com.VendingMachine.VendingMachine01.Service.InventoryService;
import com.VendingMachine.VendingMachine01.model.Inventry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.*;

import java.util.List;
@RestController
public class ProductController {

    private InventoryService inventoryService;
    Logger log = LoggerFactory.getLogger(ProductController.class);


    public ProductController(InventoryService inventoryService) {
        this.inventoryService = inventoryService;
    }


    @GetMapping("/")
    @ResponseBody
    public List<InventoryDTO> getListOfAllInventory() {
        return inventoryService.getListOfAllInventory();
    }

    @GetMapping("/product/{id}")
    @ResponseBody
    public InventoryDTO getProductById(@PathVariable int id) {
        return inventoryService.getProductById(id);
    }

    @PutMapping("/product")
    public VendingMachineOutputDTO ProductPurchase(@RequestBody CustomerInputDTO customerInputDTO) {

      return   inventoryService.purchaseProduct(customerInputDTO );
        //return "Collect your " + inventoryService.getProductById(id).getName() + " and Balance " + changeAmount + " rupees";
    }



//
//    @PutMapping("initialBalance/{changeAmt}")
//    public String updateChangeAMT(@PathVariable int changeAmt){
//        inventoryService.updateInitialBalance(changeAmt);
//        return "initial Balance updated with "+changeAmt;
//    }











    //////////////////////////////////////////////////////
    @GetMapping("/getByStockRange")
    public List<Inventry> getByStock(@RequestParam(value="productInventryCount",required = true) int productInventryCount){
        return inventoryService.productWithInStockRange(productInventryCount);
    }
    @GetMapping("/product/ProductInventryCount/{productInventryCount}")
    @ResponseBody
    public Inventry getProductByProductInventryCount(@PathVariable int productInventryCount) {
        return inventoryService.getProductByProductInventryCount(productInventryCount);
    }
////////////////////////////////////////////////////////

    @DeleteMapping("/products/{id}")
    @ResponseBody
    public String deleteProductById(@PathVariable int id) {
        return inventoryService.deleteProductById(id)+" Product(s) delete from the database";
    }

    @PostMapping("/products")
    @ResponseBody
    public String saveInventory(@RequestBody Inventry e) {
        return inventoryService.saveInventory(e) + " product added successfully";
    }

    @PutMapping("/productsput/{id}")
    @ResponseBody
    public String updateInventory(@RequestBody Inventry e, @PathVariable int id) {
        return inventoryService.updateInventory(e, id)+" Product (s) updated successfully";
    }








}
