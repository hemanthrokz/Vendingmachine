package com.VendingMachine.VendingMachine01.CustomeException;

public class InsufficientInputCashException extends RuntimeException {


    public InsufficientInputCashException(String message) {
        super(message);
    }

    public InsufficientInputCashException(String message, Throwable cause) {
        super(message, cause);
    }
}
