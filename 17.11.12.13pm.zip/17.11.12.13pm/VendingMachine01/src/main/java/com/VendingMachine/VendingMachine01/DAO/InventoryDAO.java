package com.VendingMachine.VendingMachine01.DAO;

import com.VendingMachine.VendingMachine01.model.InventoryBuilder;
import com.VendingMachine.VendingMachine01.model.Inventry;

import java.util.List;

public interface InventoryDAO {

   public List<InventoryBuilder> findAll();

   public List<InventoryBuilder> findById(int productId);

   public int deleteById(int productId);

   public int save(Inventry e);

   public int update(Inventry e, int productId);

   public int updatedStock(int productId, int productInventryCount) ;
   public List<Inventry> findByProductInventryCount(int productInventryCount);

  // public  Inventry getChange();


  // double updateChange(double newChange);
}
