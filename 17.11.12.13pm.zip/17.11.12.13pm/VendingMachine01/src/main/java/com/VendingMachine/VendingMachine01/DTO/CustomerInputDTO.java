package com.VendingMachine.VendingMachine01.DTO;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

//class for only input parameters
public class CustomerInputDTO {
    @NotNull
    private int productId;
    @NotNull
    @Size(min = 0, max = 50)
    private int price;

    public CustomerInputDTO(int productId, int price) {
        this.productId = productId;
        this.price = price;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }
}
