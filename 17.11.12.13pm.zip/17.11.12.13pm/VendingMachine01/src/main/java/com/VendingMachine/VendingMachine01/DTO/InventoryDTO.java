package com.VendingMachine.VendingMachine01.DTO;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import java.io.Serializable;

public class InventoryDTO implements Serializable {
    @NotNull
    private int productId;
    private String name;
    @NotNull
    @Size(min = 0, max = 50)
    private int productPrice;
    @NotNull
    @Size(min = 0, max = 20)
    private int productInventryCount;

    public InventoryDTO() {
    }

    public InventoryDTO(int productId, String name, int productPrice, int productInventryCount) {
        this.productId = productId;
        this.name = name;
        this.productPrice = productPrice;
        this.productInventryCount = productInventryCount;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(int productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductInventryCount() {
        return productInventryCount;
    }

    public void setProductInventryCount(int productInventryCount) {
        this.productInventryCount = productInventryCount;
    }
}
