package com.VendingMachine.VendingMachine01.controller;

import com.VendingMachine.VendingMachine01.DAO.InventoryDAO;
import com.VendingMachine.VendingMachine01.model.Inventry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    private InventoryDAO productService;



    @GetMapping("/")
    public List<Inventry> getListOfAllInventory() {
        return productService.findAll();
    }

    @GetMapping("/product/{id}")
    public Inventry getProductById(@PathVariable int id) {
        return productService.findById(id);
    }

    @DeleteMapping("/products/{id}")
    public String deleteProductById(@PathVariable int id) {
        return productService.deleteById(id)+" Product(s) delete from the database";
    }

    @PostMapping("/products")
    public String saveInventory(@RequestBody Inventry e) {
        return productService.save(e)+" Product(s) saved successfully";
    }

    @PutMapping("/products/{id}")
    public String updateInventory(@RequestBody Inventry e, @PathVariable int id) {
        return productService.update(e, id)+" Product (s) updated successfully";
    }
}
