package com.VendingMachine.VendingMachine01.DTO;

import java.io.Serializable;

//import lombok.AllArgsConstructor;
//import lombok.Data;
//import lombok.NoArgsConstructor;
//
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
public class InventoryDTO implements Serializable {

    private int productId;
    private String name;
    private double productPrice;
    private int productInventryCount;

    public InventoryDTO() {
    }

    public InventoryDTO(int productId, String name, double productPrice, int productInventryCount) {
        this.productId = productId;
        this.name = name;
        this.productPrice = productPrice;
        this.productInventryCount = productInventryCount;
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public double getProductPrice() {
        return productPrice;
    }

    public void setProductPrice(double productPrice) {
        this.productPrice = productPrice;
    }

    public int getProductInventryCount() {
        return productInventryCount;
    }

    public void setProductInventryCount(int productInventryCount) {
        this.productInventryCount = productInventryCount;
    }
}
