package com.VendingMachine.VendingMachine01.Service;

import com.VendingMachine.VendingMachine01.DAO.InventoryDAOImp;
import com.VendingMachine.VendingMachine01.model.Inventry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class InventoryService {

    @Autowired
    InventoryDAOImp repository;

    public int saveInventory(Inventry inventry){
        return repository.save(inventry);
    }

    public int updateInventory(Inventry inventry,int productId){
        return repository.update(inventry,productId);
    }

    public List<Inventry> getListOfAllInventory(){
        return repository.findAll();
    }

    public Inventry getProductById(int productId){
        return repository.findById(productId);
    }

    public int deleteProductById(int productId){
        return repository.deleteById(productId);
    }


}
