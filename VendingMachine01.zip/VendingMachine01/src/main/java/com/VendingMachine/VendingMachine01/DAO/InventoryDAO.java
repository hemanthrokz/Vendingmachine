package com.VendingMachine.VendingMachine01.DAO;

import com.VendingMachine.VendingMachine01.model.Inventry;

import java.util.List;

public interface InventoryDAO {

   public List<Inventry> findAll();

   public Inventry findById(int productId);

   public int deleteById(int productId);

   public int save(Inventry e);

   public int update(Inventry e, int productId);
}
