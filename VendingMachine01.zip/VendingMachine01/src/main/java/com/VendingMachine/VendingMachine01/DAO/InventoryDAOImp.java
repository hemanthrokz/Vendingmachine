package com.VendingMachine.VendingMachine01.DAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import com.VendingMachine.VendingMachine01.model.Inventry;

import java.util.List;

@Repository
public class InventoryDAOImp implements InventoryDAO {

    @Autowired
    JdbcTemplate jdbcTemplate;

    @Override
    public List<Inventry> findAll() {
        return jdbcTemplate.query("SELECT * FROM customer", new BeanPropertyRowMapper<Inventry>(Inventry.class));
    }

    @Override
    public Inventry findById(int productId) {
        return jdbcTemplate.queryForObject("SELECT * FROM customer WHERE productid=?", new BeanPropertyRowMapper<Inventry>(Inventry.class), productId);
    }

    @Override
    public int deleteById(int productId) {
        return jdbcTemplate.update("DELETE FROM customer WHERE productid=?", productId);
    }

    @Override
    public int save(Inventry e) {
        return jdbcTemplate.update("INSERT INTO customer (name, productinventrycount, productprice) VALUES (?, ?, ?)", new Object[] {e.getName(), e.getProductInventryCount(), e.getProductPrice()});
    }

    @Override
    public int update(Inventry e, int productId) {
        return jdbcTemplate.update("UPDATE customer SET name = ?, productinventrycount = ?, productprice = ? WHERE productid = ?", new Object[] {e.getName(), e.getProductInventryCount(), e.getProductPrice(), productId});
    }
}
