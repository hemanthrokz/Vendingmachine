package com.VendingMachine.vending.machine;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VendingMachineApplicationTests {

	@Test
	void contextLoads() {
	}

}
